package com.encora.test.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TopChar {

    private int count;
    private char character;
}
