package com.encora.test.dto;

import lombok.Data;

@Data
public class Input {

    private String text;
}
